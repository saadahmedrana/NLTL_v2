"""Separate bulk RDF evaluator."""

