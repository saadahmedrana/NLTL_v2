"""Conditional canonical vocabulary matching."""

