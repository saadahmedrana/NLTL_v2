"""Pipeline orchestration."""

