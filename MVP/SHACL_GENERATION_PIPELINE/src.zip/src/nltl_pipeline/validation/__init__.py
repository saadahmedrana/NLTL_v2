"""Deterministic generated-SHACL validation."""

