import unittest,os,json,pathlib,copy,tempfile
from unittest.mock import patch
from rdflib import Graph
from rdflib.namespace import SH
from nltlv2.core import Project,Candidate,finding,load,offline_network_guard
from nltlv2.schema import Schema
from nltlv2.checks import check
from nltlv2.development_checks import assess
from nltlv2.sparql_analysis import analyze
from nltlv2.tracking import Tracker,structural_fingerprint
from nltlv2.runner import Runner
from nltlv2.transport import ScriptedTransport
from nltlv2.requests import repair_request,assert_integrity
from test_development_behavior import control,wrap,ACCEPT

class V040RepairControlTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.p=Project(os.environ['NLTL_TEST_PROJECT']);cls.s=Schema(cls.p);cls.out=pathlib.Path(os.environ['NLTL_TEST_OUTPUT']);cls.inputs=load(cls.p.path('smoke_tests/regression_inputs/i2_004_v031/manifest.json'));cls.candidates=[];cls.replays=[]
  for item in cls.inputs['candidates']:
   code=cls.p.path(item['file']).read_text();c=Candidate(item['version'],code,code);assert c.sha256==item['sha256'];cls.candidates.append(c);fs=check(c,cls.s,'I2-004');bf,r=assess(c,cls.s,'I2-004');cls.replays.append((fs+bf,r))
 def projection_control(self):return self.candidates[4].code.replace('?focus','?this')
 def query(self,version):return str(next(Graph().parse(data=self.candidates[version-1].code,format='turtle').objects(None,SH.select)))
 def test_byte_identical_original_contract_and_candidates(self):
  import hashlib
  self.assertEqual(hashlib.sha256(self.p.path('data/contracts/development_witness_contracts.json').read_bytes()).hexdigest(),self.inputs['source_contract_sha256']);self.assertEqual(hashlib.sha256(self.p.path('schema/Schema_for_NLTL.ttl').read_bytes()).hexdigest(),self.inputs['schema_sha256'])
 def test_all_saved_behavioral_failures_reproduced(self):
  expected=[{'below_max','near_miss','missing_result','missing_case_operand'}]+[{'one','max_last','max_first','tie','fraction'}]*3
  for (_,r),e in zip(self.replays[:4],expected):self.assertEqual({w['witness_id'] for w in r['witnesses'] if w['status']=='CONFIRMED_COUNTEREXAMPLE'},e)
 def test_saved_v5_confirmed_projection_not_behavioral_rejection(self):
  fs,r=self.replays[4];self.assertEqual(r['status'],'UNASSESSABLE_CANDIDATE_ERROR');self.assertEqual(len(r['witnesses']),13);self.assertTrue(all(w['status']=='UNASSESSABLE_CANDIDATE_ERROR' for w in r['witnesses']));self.assertTrue(any(f.category=='SPARQL_ERROR' and f.confirmed and 'nested_prebound_projection' in f.check_id for f in fs));self.assertFalse(any(f.assessment=='DEMONSTRATED_BEHAVIORAL_FAILURE' for f in fs));self.assertTrue(any('All potentially pre-bound' in f.diagnostic for f in fs))
 def test_this_sigil_equivalence_and_valid_subquery_controls(self):
  for sigil in ['?','$']:
   q='SELECT $this WHERE { { SELECT '+sigil+'this (MAX(?v) AS ?m) WHERE { '+sigil+'this <urn:p> ?v } GROUP BY '+sigil+'this } FILTER(?m > 0) }'
   fs,r=analyze(Candidate(1,q,q),q);self.assertEqual(fs,[],[(f.message,f.diagnostic) for f in fs]);self.assertEqual(r['nested_selects'][0]['missing_prebound'],[])
 def test_valid_union_controls(self):
  for q in ['SELECT $this WHERE { { $this <urn:a> ?v . FILTER(?v > 0) } UNION { $this <urn:b> ?v . FILTER(?v > 0) } }','SELECT $this WHERE { { $this <urn:a> ?v } UNION { $this <urn:b> ?v } FILTER(?v > 0) }']:
   self.assertEqual(analyze(Candidate(1,q,q),q)[0],[])
 def test_valid_combined_union_and_nested_projection(self):
  q='SELECT $this WHERE { { SELECT ?this ?v WHERE { { ?this <urn:a> ?v } UNION { ?this <urn:b> ?v } } } FILTER(?v > 0) }';self.assertEqual(analyze(Candidate(1,q,q),q)[0],[])
 def test_select_star_uses_exact_engine_diagnostic(self):
  q='SELECT $this WHERE { { SELECT * WHERE { $this <urn:a> ?v } } }';fs,_=analyze(Candidate(1,q,q),q);self.assertTrue(any("Using 'SELECT *'" in f.diagnostic for f in fs))
 def test_union_scope_warnings_are_not_confirmed_errors(self):
  fs,_=analyze(self.candidates[1],self.query(2));self.assertEqual(len(fs),2);self.assertTrue(all(f.category=='SPARQL_STATIC_WARNING' and not f.blocking and not f.confirmed for f in fs));self.assertTrue(all('resultValue' in f.diagnostic for f in fs))
 def test_preserve_five_same_location_witness_findings(self):
  fs,_=self.replays[1];bf=[f for f in fs if f.witness_id];self.assertEqual(len(bf),5);self.assertEqual(len({f.key for f in bf}),5)
 def test_query_changes_do_not_resolve_failures(self):
  tracker=Tracker();changes=[]
  for c,(fs,r) in zip(self.candidates,self.replays):changes.append(tracker.observe(c,fs,r)[0])
  for idx in [2,3]:
   persistent=[x for x in changes[idx]['details'] if x['witness_id'] and x['state']=='PERSISTENT'];self.assertEqual(len(persistent),5)
  final=[x for x in changes[4]['details'] if x['witness_id']];self.assertEqual(len(final),9);self.assertTrue(all(x['state']=='UNASSESSABLE' for x in final));self.assertFalse(any(x['witness_id'] and x['state']=='RESOLVED' for x in changes[4]['details']))
 def test_regressed_finding_after_assessed_resolution(self):
  tracker=Tracker();bad=self.replays[0];tracker.observe(self.candidates[0],*bad)
  good=control(self.s.development_witness_contracts['I2-004']);g=Candidate(2,good,good);gf,gr=assess(g,self.s,'I2-004');changes,_=tracker.observe(g,gf,gr);self.assertEqual(len([x for x in changes['details'] if x['witness_id'] and x['state']=='RESOLVED']),4)
  b=Candidate(3,self.candidates[0].code,self.candidates[0].raw);bf,br=assess(b,self.s,'I2-004');changes,_=tracker.observe(b,bf,br);self.assertEqual(len(changes['regressed']),4)
 def test_oscillation_and_persistent_failure_detection(self):
  tracker=Tracker();summaries=[]
  for c,(fs,r) in zip(self.candidates[:4],self.replays[:4]):summaries.append(tracker.observe(c,fs,r)[1])
  self.assertTrue(summaries[-1]['repeat_detection']['oscillation']);self.assertIn(2,summaries[-1]['repeat_detection']['returns_to_versions']);self.assertEqual(summaries[-1]['repeat_detection']['consecutive_same_failure_set'],3)
 def test_unchanged_candidate_detected(self):
  tracker=Tracker();c=self.candidates[1];fs,r=self.replays[1];tracker.observe(c,fs,r);_,summary=tracker.observe(Candidate(3,c.code,c.raw),[__import__('dataclasses').replace(f,version=3) for f in fs],r);self.assertTrue(summary['repeat_detection']['unchanged_candidate']);self.assertIsNone(tracker.stagnation_stop({'enabled':False}));self.assertIsNotNone(tracker.stagnation_stop({'enabled':True,'unchanged_candidate_limit':1}))
 def test_missing_constraint_has_insertion_context_no_fake_token(self):
  fs,_=self.replays[0];f=next(x for x in fs if x.witness_id=='missing_result');d=json.loads(f.diagnostic);self.assertEqual(f.excerpt,'');self.assertIsNone(d['offending_token']);self.assertTrue(d['insertion_context']['required_paths']);self.assertIn('insertion context',f.location);self.assertEqual(d['minimal_relevant_input'],{'items':['13']})
 def test_behavioral_feedback_has_binding_and_source_evidence(self):
  fs,_=self.replays[1];f=next(x for x in fs if x.witness_id=='one');d=json.loads(f.diagnostic);self.assertTrue(d['binding_evidence'][0]['binding_warnings']);self.assertTrue(d['source']['exact_excerpt']);self.assertTrue(d['original_validation_log']);self.assertEqual(f.query_sha256,__import__('nltlv2.core',fromlist=['digest']).digest(self.query(2)))
 def run_script(self,name,cfg,responses):
  out=self.out/name;out.mkdir();transport=ScriptedTransport(responses);result=Runner(self.p,cfg,transport,out).run('I2-004');return result,transport,out
 def test_seeded_candidate_error_repair_no_generation(self):
  good=self.projection_control();cfg=self.p.config('configs/i2_004_repair_diagnostic.json');r,t,out=self.run_script(self._testMethodName,cfg,[wrap(good),ACCEPT]);self.assertEqual(r['status'],'ACCEPTED');self.assertEqual(r['accepted_version'],2);self.assertEqual(r['generation_calls'],0);self.assertEqual(t.calls[0]['route'],'targeted_repair');payload=t.calls[0]['payload'];self.assertEqual(payload['previous_candidate'],self.candidates[4].code);self.assertTrue(payload['persistent_failure_summary']);self.assertTrue(any('All potentially pre-bound' in f['diagnostic'] for f in payload['current_findings']));self.assertTrue((out/'request_001_integrity.json').exists())
 def test_candidate_runtime_error_remains_repairable_within_budget(self):
  cfg=self.p.config('configs/nltl.json');cfg['maximum_candidate_attempts']=2;good=self.projection_control();r,t,_=self.run_script(self._testMethodName,cfg,[wrap(self.candidates[4].code),wrap(good),ACCEPT]);self.assertEqual(r['accepted_version'],2);self.assertEqual(r['candidate_attempts'],2)
 def test_stagnation_disabled_preserves_six_attempt_cap(self):
  cfg=self.p.config('configs/nltl.json');r,t,out=self.run_script(self._testMethodName,cfg,[wrap(self.candidates[1].code)]*6);self.assertEqual(r['status'],'ATTEMPT_LIMIT_EXHAUSTED');self.assertEqual(r['candidate_attempts'],6);self.assertEqual(len(t.calls),6);self.assertTrue(t.calls[-1]['payload']['persistent_failure_summary']['repeat_detection']['repeated_behavioral_failure_set'])
 def test_explicit_stagnation_stop(self):
  cfg=self.p.config('configs/nltl.json');cfg['stagnation']=dict(enabled=True,repeated_failure_set_limit=2);r,t,_=self.run_script(self._testMethodName,cfg,[wrap(self.candidates[1].code)]*2);self.assertEqual(r['status'],'STAGNATION_STOP');self.assertEqual(r['candidate_attempts'],2);self.assertEqual(cfg['maximum_candidate_attempts'],6)
 def test_infrastructure_stops_no_repair(self):
  cfg=self.p.config('configs/nltl.json')
  with patch.dict('nltlv2.development_checks._CACHE',{},clear=True), patch('pyshacl.validate',side_effect=OSError('synthetic infrastructure failure')):
   r,t,_=self.run_script(self._testMethodName,cfg,[wrap(self.candidates[0].code)])
  self.assertEqual(r['status'],'INFRASTRUCTURE_FAILURE');self.assertEqual(len(t.calls),1)
 def test_timeout_uncertain_stops_without_code_blame(self):
  cfg=self.p.config('configs/nltl.json')
  with patch.dict('nltlv2.development_checks._CACHE',{},clear=True), patch('pyshacl.validate',side_effect=TimeoutError('synthetic timeout')):
   r,t,_=self.run_script(self._testMethodName,cfg,[wrap(self.candidates[0].code)])
  self.assertEqual(r['status'],'RESOURCE_ATTRIBUTION_UNCERTAIN');self.assertEqual(len(t.calls),1);self.assertTrue(all(not f['confirmed'] for f in r['history'][0]['findings'] if f['category']=='RESOURCE_UNCERTAIN'))
 def test_regression_guard_still_detects_deleted_obligation(self):
  from nltlv2.checks import regression
  old=Candidate(1,'@prefix sh: <http://www.w3.org/ns/shacl#> . <urn:s> sh:property [ sh:path <urn:p> ; sh:minCount 1 ] .','');new=Candidate(2,'@prefix sh: <http://www.w3.org/ns/shacl#> . <urn:s> sh:property [ sh:path <urn:p> ] .','');self.assertTrue(regression(old,new))
 def test_subquery_hidden_operand_is_static_warning(self):
  q='SELECT $this WHERE { { SELECT ?this WHERE { ?this <urn:a> ?v } } FILTER(?v > 0) }';fs,_=analyze(Candidate(1,q,q),q);self.assertTrue(any('v' in f.diagnostic for f in fs));self.assertTrue(all(not f.blocking for f in fs))
 def test_valid_missingness_default_control(self):
  q='SELECT $this WHERE { BIND(COALESCE(?absent,0) AS ?v) FILTER(?v > 0) }';self.assertEqual(analyze(Candidate(1,q,q),q)[0],[])
 def test_contradictory_feedback_stops_dispatch(self):
  cfg=self.p.config('configs/nltl.json')
  with patch('nltlv2.runner.review_conflicts',return_value=[{'diagnostic':'synthetic explicit-contract conflict'}]):r,t,_=self.run_script(self._testMethodName,cfg,[wrap(self.projection_control()),ACCEPT])
  self.assertEqual(r['status'],'CONFLICT');self.assertEqual(len(t.calls),2)
 def test_request_integrity_failure_stops_before_transport(self):
  class Tamper(ScriptedTransport):
   def dispatch(self,request,latest=None,expected_findings=None):
    if request['route'].endswith('repair'):request['payload']['previous_candidate']=''
    return super().dispatch(request,latest,expected_findings)
  cfg=self.p.config('configs/nltl.json');out=self.out/self._testMethodName;out.mkdir();t=Tamper([wrap(self.candidates[0].code)]);r=Runner(self.p,cfg,t,out).run('I2-004');self.assertEqual(r['status'],'REQUEST_INTEGRITY_FAILURE');self.assertEqual(len(t.calls),1)
 def test_regression_guard_survives_later_unrelated_edits(self):
  from nltlv2.checks import regression
  old=Candidate(1,'@prefix sh: <http://www.w3.org/ns/shacl#> . <urn:s> sh:property [ sh:path <urn:p> ; sh:minCount 1 ] .','');bad=Candidate(2,'@prefix sh: <http://www.w3.org/ns/shacl#> . <urn:s> sh:property [ sh:path <urn:p> ] .','');fs=regression(old,bad);tracker=Tracker();tracker.observe(bad,fs,{'status':'NOT_CONFIGURED'});later=Candidate(3,bad.code+'\n','');carry=tracker.carry_unrestored_guards(later,[]);self.assertEqual(len(carry),1);self.assertEqual(carry[0].version,3);self.assertTrue(carry[0].blocking)
 def test_query_parser_error_is_repairable_candidate_failure(self):
  cfg=self.p.config('configs/nltl.json');cfg['maximum_candidate_attempts']=2;good=self.projection_control();bad=good.replace('SELECT DISTINCT $this','SELECT WHERE');r,t,_=self.run_script(self._testMethodName,cfg,[wrap(bad),wrap(good),ACCEPT]);self.assertEqual(r['accepted_version'],2);self.assertTrue(any(f['category']=='SPARQL_ERROR' for f in r['history'][0]['findings']))
 def test_seed_cannot_silently_change_requirement(self):
  cfg=self.p.config('configs/i2_004_repair_diagnostic.json');out=self.out/self._testMethodName;out.mkdir();t=ScriptedTransport([])
  with self.assertRaisesRegex(ValueError,'SEED_SCOPE_MISMATCH'):Runner(self.p,cfg,t,out).run('I2-005')
  self.assertEqual(t.calls,[])
 def test_missing_prefix_context_is_warning_not_invented_binding(self):
  q='SELECT $this WHERE { $this supplied:p ?v }';fs,r=analyze(Candidate(1,q,q),q);self.assertTrue(r['unresolved_static_context']);self.assertTrue(fs);self.assertTrue(all(not f.blocking and not f.confirmed for f in fs))
 def test_v2_positive_witness_regressions_are_explicit(self):
  tracker=Tracker();tracker.observe(self.candidates[0],*self.replays[0]);changes,_=tracker.observe(self.candidates[1],*self.replays[1]);regressed=[x for x in changes['details'] if x['witness_id'] and x['state']=='REGRESSED'];self.assertEqual(len(regressed),5)
 def test_valid_union_maximum_control_is_internally_accepted(self):
  from rdflib import Literal
  generic=control(self.s.development_witness_contracts['I2-004']);graph=Graph().parse(data=generic,format='turtle');owner=next(graph.subjects(SH.targetClass,None));nodes=list(graph.objects(owner,SH.sparql));self.assertEqual(len(nodes),2)
  queries=[str(graph.value(node,SH.select)) for node in nodes];bodies=[q.partition('WHERE {')[2].rsplit('}',1)[0] for q in queries]
  query='PREFIX q: <http://qudt.org/schema/qudt/> SELECT $this WHERE { { '+bodies[0]+' } UNION { '+bodies[1]+' } }'
  for node in nodes:graph.remove((owner,SH.sparql,node));graph.remove((node,None,None))
  graph.add((owner,SH.sparql,nodes[0]));graph.add((nodes[0],SH.select,Literal(query)));code=graph.serialize(format='turtle');cfg=self.p.config('configs/nltl.json');r,t,_=self.run_script(self._testMethodName,cfg,[wrap(code),ACCEPT]);self.assertEqual(r['status'],'ACCEPTED');self.assertEqual(r['accepted_version'],1);self.assertFalse(r['history'][0]['static_warnings']);self.assertEqual(r['history'][0]['development_coverage']['status'],'FINITE_WITNESSES_PASSED')
