"""Development-only source contracts and synthetic inputs; no external fixtures."""
import unittest,os,json,re,dataclasses,copy,pathlib
from rdflib import Graph,URIRef,Literal,XSD
from rdflib.namespace import SH
from pyshacl import validate
from nltlv2.core import Project,Candidate,digest,finding,offline_network_guard
from nltlv2.schema import Schema
from nltlv2.checks import check,regression
from nltlv2.constraint_changes import review,grants,preservation_conflicts
from nltlv2.development_checks import assess,contracts,expected,graph_for,witness_vectors
from nltlv2.requests import repair_request,assert_integrity
from nltlv2.runner import Runner
from nltlv2.transport import ScriptedTransport
from nltlv2.tracking import Tracker
from test_development_behavior import control,wrap,ACCEPT

BASE='smoke_tests/regression_inputs/v040_numeric_selector/'
class NumericPreservationTests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.p=Project(os.environ['NLTL_TEST_PROJECT']);cls.s=Schema(cls.p);cls.out=pathlib.Path(os.environ['NLTL_TEST_OUTPUT']);cls.cs=contracts(cls.s)
 def saved(self,rid,v):
  code=self.p.path(BASE+rid+'_candidate_'+str(v).zfill(2)+'.ttl').read_text();return Candidate(v,code,wrap(code))
 def fixed(self,c):
  if 'shellInclinationAngle' in c.code:return c.code.replace('sh:hasValue "7"^^xsd:decimal','sh:minInclusive "7"^^xsd:decimal ; sh:maxInclusive "7"^^xsd:decimal')
  return re.sub(r'sh:in\s*\([^)]*\)\s*;','',c.code)
 def guard(self,a,b,fs=None):return regression(a,b,review(a,self.s,'IMO-001') if fs is None else fs,schema=self.s,rid='IMO-001')
 def test_saved_numeric_defect_now_blocks(self):
  c=self.saved('I2-005',2);fs=check(c,self.s,'I2-005');n=[f for f in fs if f.assessment=='INDEPENDENTLY_VALIDATED_CONSTRAINT_CHANGE'];self.assertEqual(len(n),1);self.assertIn('sh:hasValue',n[0].excerpt);self.assertIn('numericValue',n[0].location);self.assertIn('original_validation_log',json.loads(n[0].diagnostic));bf,cov=assess(c,self.s,'I2-005');self.assertEqual({r['witness_id'] for r in cov['witnesses'] if r['status']=='CONFIRMED_COUNTEREXAMPLE'},{'numeric-lexical-equivalent-0','numeric-lexical-equivalent-1'})
 def test_equivalent_unequal_and_datatype_controls(self):
  ct=self.cs['I2-005'];good=control(ct);c=Candidate(1,good,wrap(good));self.assertFalse(assess(c,self.s,'I2-005')[0]);self.assertFalse(review(c,self.s,'I2-005'))
  for lex,want in [('7',True),('7.0',True),('7.00',True),('+7.000',True),('07.0',True),('6.999',False),('7.001',False)]:
   v=dict(id='synthetic',values={'items':[dict(number=lex,unit=ct['fields']['items']['unit'])]});self.assertEqual(expected(ct,v['values']),want);self.assertEqual(validate(graph_for(ct,v,self.s),shacl_graph=Graph().parse(data=good),ont_graph=self.s.graph,inference='rdfs',advanced=True)[0],want)
  for dt in [XSD.string,XSD.integer,XSD.float]:
   v=dict(id='type',values={'items':[dict(number='7',unit=ct['fields']['items']['unit'],datatype=str(dt))]});self.assertFalse(expected(ct,v['values']));self.assertFalse(validate(graph_for(ct,v,self.s),shacl_graph=Graph().parse(data=good),ont_graph=self.s.graph,inference='rdfs',advanced=True)[0])
 def test_datatype_not_relaxed(self):
  ct=self.cs['I2-005'];code=control(ct).replace('sh:datatype xsd:decimal','sh:nodeKind sh:Literal');_,cov=assess(Candidate(1,code,code),self.s,'I2-005');self.assertTrue(any(r['witness_id'].startswith('numeric-required-datatype') and r['status']=='CONFIRMED_COUNTEREXAMPLE' for r in cov['witnesses']))
 def test_exact_term_hasvalue_remains_valid(self):
  code='@prefix sh:<http://www.w3.org/ns/shacl#>. @prefix xsd:<http://www.w3.org/2001/XMLSchema#>. <urn:shape> sh:targetNode <urn:s>; sh:property [sh:path <urn:p>; sh:datatype xsd:decimal; sh:hasValue "7"^^xsd:decimal].'
  c=Candidate(1,code,code);self.assertEqual(review(c,self.s,'TRF-010'),[])
  for lexical,want in [('7',True),('7.0',False)]:
   g=Graph();g.add((URIRef('urn:s'),URIRef('urn:p'),Literal(lexical,datatype=XSD.decimal,normalize=False)));self.assertEqual(validate(g,shacl_graph=Graph().parse(data=code))[0],want)
 def test_numeric_replacement_permission(self):
  a=self.saved('I2-005',2);b=Candidate(3,self.fixed(a),'');self.assertFalse(regression(a,b,review(a,self.s,'I2-005'),schema=self.s,rid='I2-005'));self.assertFalse(assess(b,self.s,'I2-005')[0])
 def test_numeric_compound_datatype_edit_blocked(self):
  a=self.saved('I2-005',2);b=Candidate(3,self.fixed(a).replace('sh:datatype xsd:decimal','sh:datatype xsd:string'),'');self.assertTrue(regression(a,b,review(a,self.s,'I2-005'),schema=self.s,rid='I2-005'))
 def test_historical_selector_all_six_and_minimal_removals(self):
  for v in range(1,7):
   a=self.saved('IMO-001',v);self.assertEqual(bool(review(a,self.s,'IMO-001')),bool(v%2));_,cov=assess(a,self.s,'IMO-001');self.assertEqual(sum(r['status']=='CONFIRMED_COUNTEREXAMPLE' for r in cov['witnesses']),2 if v%2 else 0)
  for v in [1,3,5]:
   a=self.saved('IMO-001',v);b=Candidate(v+1,self.fixed(a),'');self.assertFalse(self.guard(a,b));self.assertFalse(assess(b,self.s,'IMO-001')[0])
  for v in [3,5]:self.assertFalse(self.guard(self.saved('IMO-001',v),self.saved('IMO-001',v+1)))
 def test_historical_v1_query_compound_not_blanket_authorized(self):
  self.assertTrue(self.guard(self.saved('IMO-001',1),self.saved('IMO-001',2)))
 def test_selector_readiness_deletion_blocked(self):
  a=self.saved('IMO-001',5);b=Candidate(6,self.fixed(a).replace('sh:minCount 1 ;',''),'');self.assertTrue(self.guard(a,b));self.assertTrue(assess(b,self.s,'IMO-001')[0])
 def test_conditional_deletion_blocked(self):
  a=self.saved('IMO-001',5);b=Candidate(6,self.fixed(a).replace('FILTER NOT EXISTS','FILTER EXISTS'),'');self.assertTrue(self.guard(a,b))
 def test_unrelated_and_target_deletions_blocked(self):
  a=self.saved('IMO-001',5)
  for old,new in [('sh:class nltl:polarShipCategoryValue ;',''),('sh:targetClass nltl:ship','sh:targetClass nltl:iceConditionValue')]:
   self.assertTrue(self.guard(a,Candidate(6,self.fixed(a).replace(old,new),'')))
 def test_stale_version_and_hash_authorizations_rejected(self):
  a=self.saved('IMO-001',5);fs=review(a,self.s,'IMO-001');b=Candidate(6,self.fixed(a),'')
  for stale in [Candidate(4,a.code,''),Candidate(5,a.code+'\n','')]:
   with self.assertRaisesRegex(ValueError,'AUTHORIZATION_INTEGRITY'):self.guard(stale,b,fs)
 def test_model_cannot_self_authorize(self):
  a=self.saved('IMO-001',5);b=Candidate(6,self.fixed(a),'');f=finding(a,'SOURCE_BACKED_LOGIC_ERROR','model suggests delete',a.code,evidence='unsupported claim',suggestion='delete');self.assertTrue(self.guard(a,b,[f]))
 def test_unauthorized_deletion_without_findings_blocked(self):
  a=self.saved('IMO-001',5);self.assertTrue(self.guard(a,Candidate(6,self.fixed(a),''),[]))
 def test_tampered_grant_rejected(self):
  a=self.saved('IMO-001',5);f=review(a,self.s,'IMO-001')[0];d=json.loads(f.diagnostic);d['validated_change_authorization']['locator']['steps']=[];fake=dataclasses.replace(f,diagnostic=json.dumps(d))
  with self.assertRaisesRegex(ValueError,'AUTHORIZATION_INTEGRITY'):self.guard(a,Candidate(6,self.fixed(a),''),[fake])
 def test_explicit_preservation_conflict(self):
  a=self.saved('IMO-001',5);fs=review(a,self.s,'IMO-001');grant=grants(fs)[0];sig=[grant['predicate'],grant['locator']['steps'][0][1],json.dumps(sorted(grant['value']['members']))];guard=finding(a,'SOURCE_BACKED_LOGIC_ERROR','restore unsupported closure','',diagnostic='REMOVED_OR_CHANGED '+json.dumps([sig]),assessment='REGRESSION_GUARD');self.assertEqual(preservation_conflicts(a,[guard],fs)[0].category,'PRESERVATION_CONFLICT')
 def test_compound_guard_persists_until_protected_rule_restored(self):
  a=self.saved('IMO-001',5);b=Candidate(6,self.fixed(a).replace('sh:minCount 1 ;',''),'');fs=self.guard(a,b);t=Tracker();t.observe(b,fs,{});c=Candidate(7,b.code+'\n','');carried=t.carry_unrestored_guards(c,[]);self.assertTrue(carried);self.assertTrue(t.observe(c,carried,{})[0]['persistent']);d=Candidate(8,self.fixed(a),'');self.assertFalse(t.carry_unrestored_guards(d,[]));self.assertTrue(t.observe(d,[],{})[0]['resolved'])
 def test_complete_packets_and_live_boundary_integrity(self):
  for rid,v in [('I2-005',2),('IMO-001',5)]:
   c=self.saved(rid,v);fs=check(c,self.s,rid)+assess(c,self.s,rid)[0];req=repair_request(self.p,self.s.context(rid),c,fs);self.assertTrue(req['payload']['validated_constraint_changes']);assert_integrity(req,c,fs);bad=copy.deepcopy(req);bad['payload']['validated_constraint_changes'][0]['candidate_version']=99;bad['user']=json.dumps(bad['payload'])
   with self.assertRaisesRegex(ValueError,'AUTHORIZATION_INTEGRITY'):assert_integrity(bad,c,fs)
 def test_scripted_production_repairs_latest_packet(self):
  for rid,v in [('I2-005',2),('IMO-001',5)]:
   c=self.saved(rid,v);dest=self.out/(self._testMethodName+'_'+rid);dest.mkdir();cfg=self.p.config('configs/'+('i2_005_numeric_repair_diagnostic' if rid=='I2-005' else 'imo_001_selector_repair_diagnostic')+'.json');t=ScriptedTransport([wrap(self.fixed(c)),ACCEPT]);r=Runner(self.p,cfg,t,dest).run(rid);self.assertEqual(r['accepted_version'],2,json.dumps(r));self.assertEqual(r['generation_calls'],0);self.assertEqual(r['request_count_by_route'],{'targeted_repair':1,'review':1});packet=t.calls[0];self.assertEqual(packet['payload']['previous_candidate'],c.code);self.assertTrue(packet['payload']['validated_constraint_changes']);self.assertFalse(r['history'][1]['findings'])
 def test_seeds_hashes_and_limits(self):
  for file in ['configs/i2_005_numeric_repair_diagnostic.json','configs/imo_001_selector_repair_diagnostic.json']:
   c=self.p.config(file);self.assertEqual(c['maximum_candidate_attempts'],3);self.assertEqual(c['maximum_repair_calls'],2);self.assertEqual(c['initial_generation_calls'],0);self.assertFalse(c['fresh_regeneration']);self.assertFalse(c['model_calls_authorized']);self.assertEqual(digest(self.p.path(c['seed_candidate']['path']).read_text()),c['seed_candidate']['sha256'])
 def test_only_actual_constraint_leaf_can_authorize(self):
  c=self.saved('I2-005',2);inactive=c.code.replace('sh:path qudt:numericValue ;','sh:deactivated true ; sh:path qudt:numericValue ;');self.assertFalse(review(Candidate(3,inactive,''),self.s,'I2-005'))
 def test_wrong_path_not_authorized_by_other_path_report(self):
  c=self.saved('I2-005',2);bad=c.code.replace('sh:path qudt:numericValue ;','sh:path qudt:unit ;');self.assertFalse(review(Candidate(3,bad,''),self.s,'I2-005'))
 def test_empty_or_unit_hasvalue_not_numeric_authorized(self):
  c=self.saved('I2-005',2);code=self.fixed(c);self.assertFalse(review(Candidate(3,code,''),self.s,'I2-005'));self.assertIn('sh:hasValue unit:DEG',code)
 def test_two_repair_cap_without_acceptance(self):
  cfg=self.p.config('configs/imo_001_selector_repair_diagnostic.json');a=self.saved('IMO-001',5);dest=self.out/self._testMethodName;dest.mkdir();t=ScriptedTransport([wrap(a.code),wrap(a.code)]);r=Runner(self.p,cfg,t,dest).run('IMO-001');self.assertEqual(r['status'],'ATTEMPT_LIMIT_EXHAUSTED');self.assertEqual(r['accepted_version'],None);self.assertEqual(r['request_count_by_route'],{'targeted_repair':2});self.assertEqual(r['generation_calls'],0)
 def test_production_conflict_stops_before_dispatch(self):
  from unittest.mock import patch
  a=self.saved('IMO-001',5);cfg=self.p.config('configs/imo_001_selector_repair_diagnostic.json');fs=review(Candidate(1,a.code,''),self.s,'IMO-001');grant=grants(fs)[0];sig=[grant['predicate'],grant['locator']['steps'][0][1],json.dumps(sorted(grant['value']['members']))]
  def old_guard(tracker,c,current):return [finding(c,'SOURCE_BACKED_LOGIC_ERROR','restore old selector clause','',diagnostic='REMOVED_OR_CHANGED '+json.dumps([sig]),contract_id='test',obligation_id='test',check_id='conflict',assessment='REGRESSION_GUARD')]
  # Prior independently validated findings must exist: conflict is injected on repair.
  original=Tracker.carry_unrestored_guards
  def inject(tracker,c,current):return old_guard(tracker,c,current) if c.version==2 else original(tracker,c,current)
  dest=self.out/self._testMethodName;dest.mkdir();t=ScriptedTransport([wrap(self.fixed(a))])
  with patch.object(Tracker,'carry_unrestored_guards',inject):r=Runner(self.p,cfg,t,dest).run('IMO-001')
  self.assertEqual(r['status'],'CONFLICT');self.assertEqual(len(t.calls),1);self.assertTrue(any(f['category']=='PRESERVATION_CONFLICT' for f in r['history'][-1]['findings']))
 def test_authorized_minimal_removal_blocks_duplicate_scope_deletion(self):
  a=self.saved('IMO-001',5);extra='\n<urn:another:target> a sh:NodeShape ; sh:targetClass nltl:ship ; sh:property [sh:path nltl:designIceCondition ; sh:minCount 1] .\n';a=Candidate(5,a.code+extra,'');b=Candidate(6,self.fixed(a).replace(extra,''),'');self.assertTrue(self.guard(a,b))

 def test_unrelated_exact_decimal_term_is_preserved_lexically(self):
  a=self.saved('IMO-001',5)
  extra='\n<urn:exact:control> a sh:NodeShape ; sh:targetClass nltl:ship ; sh:property [sh:path <urn:exact:term> ; sh:hasValue "7"^^<http://www.w3.org/2001/XMLSchema#decimal>] .\n'
  a=Candidate(5,a.code+extra,'');b=Candidate(6,self.fixed(a),'')
  self.assertFalse(self.guard(a,b))
  altered=Candidate(6,b.code.replace('sh:hasValue "7"^^','sh:hasValue "7.0"^^'),'')
  self.assertTrue(self.guard(a,altered))
