# NLTLv2.0 v0.7.0 — source-grounded checks and review

Both workflows receive identical original-source/schema context, generation settings and **no few-shot examples**. Single-shot makes exactly one generation call, only extracting its original response. NLTL adds general deterministic checks, execution-only activation probes and source/schema-grounded review, up to six candidates, early acceptance and no fresh regeneration. No production input contains handwritten regulatory solutions, compliance witnesses, expected verdicts or per-requirement change permissions. Independent evaluation stays under `evaluation/`, outside generation/repair.

Context now traverses declared ontology ranges, class hierarchy and relevant typed individuals (including labels), alongside the registry and JSON-LD quantity serialization. Broad ancestors are included as evidence without reverse-expanding the whole ontology. `qudt:numericValue`, `qudt:unit` and the declared decimal encoding are supplied explicitly. Unknown owners remain unknown. Identifier correction preserves constraints and numeric values; renaming a unit never performs conversion.

Deterministic source selection uses exact clause anchors, numbered parents, scope/definitions and explicit references. Exact included/omitted offsets, section hashes and unresolved references are retained in `source_selection_manifest.json`. Ambiguous anchors and explicit supporting documents remain full source; there is no token/character truncation. `Schema.source_evidence(file, document_sha256, start, end)` retrieves omitted evidence through the source-only capability. If necessary supporting interpretation is unavailable, the reviewer must mark it materially unresolved. Selection is not a proof of legal completeness.

Offline commands from this folder:

```sh
PYTHONDONTWRITEBYTECODE=1 ../NLTLv2-env/bin/python -m nltlv2 --project . check
PYTHONDONTWRITEBYTECODE=1 ../NLTLv2-env/bin/python -m nltlv2 --project . smoke
```

`smoke` blocks network/model access, exercises scripted software controls and then runs the 37-case/20-counterpart independent reference controls in a separate process. New outputs use fresh `outputs/smoke_tests/<run_id>/` directories. Reference-control success is not generated workflow performance. Credentials remain external and are never loaded by offline checks.

The reviewer protocol normalizes only documented equivalent field aliases, rejects conflicting duplicates, preserves raw/normalized responses and verifies exact evidence. Every functional removal group needs source-grounded assessment, not pre-authorized edits. Model interpretations remain unverified. Material targeting/scope uncertainty blocks acceptance, including legacy untyped `unchecked` notes. Nested shapes need no own targets when reachable from an active root; untargeted, ineffective or deactivated enforcement cannot be accepted.

The default provider mode remains bounded JSON with one configured format retry. Azure Responses documents `text.format` structured output, and the transport supports it only with an explicit verified capability declaration. Current Aalto gateway/model support has not been established; no capability or model calls were made. See `docs/v070_protocol_and_context.md`.

Required inputs for a new regulation remain ID/citation/clause, exact source and supporting documents, declared schema/datatype/unit metadata, optional evidenced representation mappings and shared settings. No regulation-specific checker or answer is required. See `docs/new_regulation_inputs.md`. Unsupported complex SPARQL, ambiguous source cross-references and unclear schema/application remain limitations. Source-grounded quotation checks do not prove entailment or full regulatory correctness.

Both v0.6.0 pilot runs and all historical scores/fixtures remain unchanged. The v0.7.0 refactor audit under `outputs/audits/` contains exact replay reasons, complete diagnostic repair packets, byte-based prompt accounting and preservation manifests. No study was run. The proposed `configs/v070_bounded_live_check.json` is prepared only and requires separate future live authorization and opt-in.
