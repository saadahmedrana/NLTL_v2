# NLTLv2.0 v0.8.0 — bounded source-grounded context resolution

Single-shot remains one generation call, using the same initial source/schema/example context and settings as NLTL. Examples: none. NLTL adds deterministic checks, bounded evidence retrieval, source/schema-grounded review and targeted repair. There are no handwritten regulatory solutions, compliance witnesses, expected verdicts or per-requirement change permissions in production. Independent evaluation remains outside generation/repair; the tracker is unchanged.

Flow: **generate → check → retrieve source/schema evidence when needed → review full unchanged candidate → request bounded further evidence, propose an evidenced repair, or stop unresolved**. Missing, unreachable or deactivated enforcement always blocks acceptance. Retrieval never edits a candidate, activates it, invents applicability or establishes query correctness. Grounded model interpretations are not independently verified facts.

Source dependencies include UR identifiers (including clause/revision references), bare cross-document clause references, PR references and numbered local references. Resolution uses only indexed retained documents, pinned hashes, publisher/edition/provenance metadata and exact bounded passages with parent context. Missing, ambiguous, incompatible, cyclic, partial and exhausted resolutions are explicit. Whole documents are not silently added to prompts; cached source reads and deduplicated passages prevent repeated loading. Unversioned references remain edition-qualified evidence, not a claim that an edition governs the case.

Relevant ontology vocabulary, labels/types/hierarchy and representation mappings can be retrieved when applicability is questioned. Vocabulary existence and broad RDFS domains do not prove eligibility. Other-requirement mappings are labelled non-transferable. Missing material binding/source context cannot be overridden by ACCEPT or by absent RDF data. A reviewer may use REQUEST_EVIDENCE or explicitly classify a blocker as repairable code versus missing information using exact source/code/schema evidence. Any repair still receives full immediately preceding code/version/hash and original diagnostics.

Default limits are separate: six candidates (including initial generation); two retrieval rounds per run; three top-level requests per round; six source documents; 24 dependency lookups; depth three; six passages/16,000 new source characters per round and 32,000 per run; 24 schema terms/300 ontology triples per round; three review rounds per candidate and eight reviews per run. Reviewer JSON format retries default to one per review and count separately. Repeated identical requests/no-new-evidence stop; infrastructure/integrity/conflict/resource failures stop. Source-hash changes prevent dispatch. No fresh regeneration.

Offline commands from this folder:

```sh
PYTHONDONTWRITEBYTECODE=1 ../NLTLv2-env/bin/python -m nltlv2 --project . check
PYTHONDONTWRITEBYTECODE=1 ../NLTLv2-env/bin/python -m nltlv2 --project . smoke
```

Software tests use scripted responses with network/model calls blocked. The 37-case/20-counterpart reference controls run separately afterward. Passing those controls does not establish automatic repair quality. Every output uses a fresh directory. Credentials remain external and are not read by offline checks. Structured output remains disabled for the unverified Aalto gateway/model; bounded JSON/strict quotations are retained.

`data/requirements/source_catalog.json` registers retained source documents, identities/editions/provenance and hashes. The imported two-page UR I1 Rev.2 (2016) source is preserved with its original PDF under `data/requirements/originals/`; the unversioned I2 reference does not establish which I1 edition governs. UR I3 and PR 29 remain unavailable. New source registration is evidence metadata, not an applicability solution.

See `docs/v080_context_resolution.md` for transitions, input requirements and limits. Historical outputs/scores/fixtures remain immutable. The saved v0.7 candidate replay is labelled software diagnostics and does not receive new workflow credit. The old v0.7 live-check config is archived in `docs/history/configs/`. `configs/v080_bounded_live_check.json` proposes one fresh two-candidate I2-004 operational check with at most four reviews (one format retry each), two retrieval rounds and no regeneration; it has NOT been dispatched. No batch/50-requirement study was run.
