"""General source-grounded NLTL pipeline. No credentials loaded on import."""
__version__ = "0.9.0"
