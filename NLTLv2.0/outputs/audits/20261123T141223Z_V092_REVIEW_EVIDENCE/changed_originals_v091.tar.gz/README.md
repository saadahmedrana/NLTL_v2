# NLTLv2.0 v0.9.1 — common research scope, isolated input admission

Generation/review/repair uses only source/schema and an explicitly approved common experimental scope. The common declaration contains no evaluation node IDs, case IDs, labels or counterpart records. Exact per-input node/hash bindings stay in independent evaluation. The v0.9.0 node-bearing generation interface is rejected. See `docs/v091_scope_decision.md` and the exact unapproved proposal in `data/admissions/i2_004_research_scope.proposed.json`.

Single-shot makes exactly one generation call; NLTL receives identical initial context/settings, then adds deterministic parsing/canonical/type/unit/path/SPARQL checks, execution-only probes and bounded source-grounded review/repair. Examples: none. No handwritten regulatory solutions, compliance witnesses, expected verdicts or bespoke permissions enter production. Missing/unapproved common scope stops before credentials/dispatch. Root activation and full query correctness remain independent obligations; resolving admission proves neither. Every repair receives the complete immediately preceding candidate/hash, exact diagnostics and source evidence. The tracker is unchanged.

Independent evaluation happens after generation; its per-input admission guard checks byte hashes, scope meaning and exact class population under RDFS. It never feeds data/labels/counterparts back into repair. Historical fixtures, classifications, scores and experiments are preserved. The 37-case/20-counterpart mathematical reference controls are conditional software/development evidence, not admission-certified workflow results.

Offline commands from this folder:

```sh
PYTHONDONTWRITEBYTECODE=1 ../NLTLv2-env/bin/python -m nltlv2 --project . check
PYTHONDONTWRITEBYTECODE=1 ../NLTLv2-env/bin/python -m nltlv2 --project . smoke
```

Tests block network/model calls; credentials remain external. Existing bounded candidate, retrieval/review/format retry limits, precise evidence checks and no-regeneration policy remain. Sources are retained edition-pinned material; missing material dependencies remain explicit. No full correctness or real-vessel certification is claimed.

The latest prepared two-candidate operational check is `configs/v091_bounded_live_check.json`. It is NOT dispatched and deliberately blocked pending actual scope approval/provenance. All earlier versioned configurations, reports and evidence remain historical; they do not select an older runtime mode. No batch or 50-requirement study was started.
